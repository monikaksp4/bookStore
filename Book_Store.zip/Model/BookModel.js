const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let BookSchema = new Schema({
    bookName: {type: String, required: true},
    bookCover: {type: String },
    price:{type:Number},
    author:{type:String},
    publishedDate:{type:Date,default:Date.now},
 }, {collection: 'book'}
);


// Export the model
module.exports = mongoose.model('Books', BookSchema);