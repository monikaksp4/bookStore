const express = require('express');
const bookRoutes = express.Router();


let BookModel = require('../Model/BookModel');

// Defined store route
bookRoutes.route('/add').post(function (req, res) {
  let book = new BookModel(req.body);
  book.save()
    .then(book => {
      res.status(200).json({'message': 'book in added successfully',book});
    })
    .catch(err => {
    res.status(400).send("unable to save to database");
    });
});

// Defined get data(index or listing) route
bookRoutes.route('/').get(function (req, res) {
    BookModel.find(function(err, bookdata){
    if(err){
      console.log(err);
    }
    else {
      res.json(bookdata);
    }
  });
});

// Defined edit route
bookRoutes.route('/edit/:id').get(function (req, res) {
  let id = req.params.id;
 BookModel.findById(id, function (err, book){
      res.json(book);
  });
});

//  Defined update route
bookRoutes.route('/update/:id').post(function (req, res) {
    BookModel.findById(req.params.id, function(err, bdata) {
    if (!bdata)
      res.status(404).send("data is not found");
    else {
        bdata.bookName = req.body.bookName;
        bdata.bookCover = req.body.bookCover;
        bdata.author = req.body.author;
        bdata.price=req.body.price;

       bdata.save().then(book => {
          res.json({'message':'Update complete'});
      })
      .catch(err => {
            res.status(400).send("unable to update the database");
      });
    }
  });
});

// Defined delete | remove | destroy route
bookRoutes.route('/delete/:id').get(function (req, res) {
    BookModel.findByIdAndRemove({_id: req.params.id}, function(err, bdata){
        if(err) res.json(err);
        else res.json('Successfully removed');
    });
});

module.exports = bookRoutes;