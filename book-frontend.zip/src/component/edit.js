import React, { Component } from 'react';
import axios from 'axios';

export default class Edit extends Component {
  constructor(props) {
    super(props);
    this.onChangeBookName = this.onChangeBookName.bind(this);
    this.onChangeBookCover= this.onChangeBookCover.bind(this);
    this.onChangePrice = this.onChangePrice.bind(this);
    this.onChangeAuthor=this.onChangeAuthor.bind(this);
    this.onSubmit = this.onSubmit.bind(this);

    this.state = {
        bookName: '',
        bookCover: '',
        price:'',
        author:'',
        bdata:''
    }
  }

  componentDidMount() {
      axios.get('http://localhost:1234/book/edit/'+this.props.match.params.id)
          .then(response => {
              this.setState({ 
                bookName:response.data.bookName,
                bookCover:response.data.bookCover,
                price:response.data.price,
                author:response.data.author});
          })
          .catch(function (error) {
              console.log(error);
          })
    }

    onChangeBookName(e) {
        this.setState({
          bookName: e.target.value
        });
      }
      onChangeBookCover(e) {
        this.setState({
          bookCover: e.target.value
        })  
      }
      onChangePrice(e) {
        this.setState({
          price: e.target.value
        })
      }
      onChangeAuthor(e) {
          this.setState({
            author: e.target.value
          })
        }
    
      onSubmit(e) {
        e.preventDefault();
        const obj={
            bookName:this.state.bookName,
            bookCover:this.state.bookCover,
            price:this.state.price,
            author:this.state.author
        }
        axios.post('http://localhost:1234/book/update/'+this.props.match.params.id, obj)
          .then((res) => 
              {
                alert(res.data.message)
             
              }
             )
    
      this.setState({
        bookName: '',
        bookCover: '',
       price: '',
       author:''
        })
      }
 
  render() {
    return (
        <div style={{ marginTop: 10 }}>
            <h3 align="center">Update Book</h3>
            <form  onSubmit={this.onSubmit}>
                    <div className="form-group">
                        <label>Book Name:  </label>
                        <input type="text" 
                        value={this.state.bookName}
                        onChange={this.onChangeBookName}
                        className="form-control"/>
                    </div>
                    <div className="form-group">
                        <label>Book Cover Name: </label>
                        <input type="text" 
                          value={this.state.bookCover}
                          onChange={this.onChangeBookCover}
                          className="form-control"/>
                    </div>
                    <div className="form-group">
                        <label>Price: </label>
                        <input type="text" 
                          value={this.state.price}
                          onChange={this.onChangePrice}
                        className="form-control"/>
                    </div>
                    <div className="form-group">
                        <label>author: </label>
                        <input type="text" 
                          value={this.state.author}
                          onChange={this.onChangeAuthor}
                        className="form-control"/>
                    </div>
                  
                    <div className="form-group">
                        <button className="btn btn-primary">Update Book</button>
                    </div>
                </form>
        </div>
    )
  }
}