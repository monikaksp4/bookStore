import React, { Component } from 'react';
import axios from 'axios'
export default class Create extends Component {
    constructor(props) {
        super(props);
        this.onChangeBookName = this.onChangeBookName.bind(this);
        this.onChangeBookCover= this.onChangeBookCover.bind(this);
        this.onChangePrice = this.onChangePrice.bind(this);
        this.onChangeAuthor=this.onChangeAuthor.bind(this);
        this.onSubmit = this.onSubmit.bind(this);
  
        this.state = {
            bookName: '',
            bookCover: '',
            price:'',
            author:'',
            bdata:''
        }
    }
    onChangeBookName(e) {
      this.setState({
        bookName: e.target.value
      });
    }
    onChangeBookCover(e) {
      this.setState({
        bookCover: e.target.value
      })  
    }
    onChangePrice(e) {
      this.setState({
        price: e.target.value
      })
    }
    onChangeAuthor(e) {
        this.setState({
          author: e.target.value
        })
      }
  
    onSubmit(e) {
      e.preventDefault();
      const obj={
          bookName:this.state.bookName,
          bookCover:this.state.bookCover,
          author:this.state.author,
          price:this.state.price,
        
      }
      axios.post('http://localhost:1234/book/add', obj)
        .then((res) => 
            
               
        alert(res.data.message)
           
            )
   
    this.setState({
        bookName: '',
        bookCover: '',
       price: '',
       author:''
      })
   
    }
    render() {
        return (
            <div style={{marginTop: 10}}>
                <h3>Add New Book</h3>
                <form  onSubmit={this.onSubmit}>
                    <div className="form-group">
                        <label>Book Name:  </label>
                        <input type="text" 
                        value={this.state.bookName}
                        onChange={this.onChangeBookName}
                        className="form-control"/>
                    </div>
                    <div className="form-group">
                        <label>Book Cover Name: </label>
                        <input type="text" 
                          value={this.state.bookCover}
                          onChange={this.onChangeBookCover}
                          className="form-control"/>
                    </div>
                    <div className="form-group">
                        <label>Price: </label>
                        <input type="text" 
                          value={this.state.price}
                          onChange={this.onChangePrice}
                        className="form-control"/>
                    </div>
                    <div className="form-group">
                        <label>Author: </label>
                        <input type="text" 
                          value={this.state.author}
                          onChange={this.onChangeAuthor}
                        className="form-control"/>
                    </div>
                  
                    <div className="form-group">
                        <button className="btn btn-primary">Add New Book</button>
                    </div>
                </form>
            </div>
        )
    }
}